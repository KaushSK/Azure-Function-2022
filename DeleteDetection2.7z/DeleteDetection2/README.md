# Introduction 

## Problem Description

When Azure Key Vault (AKV), keys, storage accounts, objects, and similar things are deleted, no report is generated and reviewed to decide whether to recover the deleted items or not. As a result, the deleted "items" could go undetected and get deleted permanently.

## Security Threat

When malicious users delete AKV, keys, storage accounts, objects and similar things, those deleted items will still be there to be recovered due to the soft-delete option. If those deleted items are not reported and reviewed, it will not be recovered. As a result, it could cause major damage to the business. For example, if a key is deleted, the data encrypted by the key will become unrecoverable.

## The Work

Please develop an Azure Function Application to scan through subscriptions and resource groups periodically (may be once a week), identify the deleted services/items, then generate a report of those items, and then send the report to 1 or more certain email addresses to review and confirm the deletions. This will give clear visibility to the deleted items and give a chance to other responsible users to validate the deletions.

# Development

I've documented the development [here](/docs/development.md).