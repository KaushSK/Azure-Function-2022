﻿using Azure.Monitor.Query.Models;

namespace SoftDeleteDetection.Models;

public class AzureDiagnostics
{
    public string TimeGenerated { get; set; }
    public string TenantId { get; set; }
    public string SourceSystem { get; set; }
    public string CallerIpAddress { get; set; }
    public string Category { get; set; }
    public string CorrelationId { get; set; }
    public string ResourceProvider { get; set; }
    public string Resource { get; set; }
    public string OperationName { get; set; }
    public string ClientInfo { get; set; }
    public string ResourceGroup { get; set; }
    public string SubscriptionId { get; set; }
    public string Type { get; set; }
    public string ResourceId { get; set; }


    public AzureDiagnostics(LogsTableRow logsTableRow)
    {
        ResourceId = logsTableRow["ResourceId"]?.ToString();
        Category = logsTableRow["Category"]?.ToString();
        ResourceGroup = logsTableRow["ResourceGroup"]?.ToString();
        SubscriptionId = logsTableRow["SubscriptionId"]?.ToString();
        ResourceProvider = logsTableRow["ResourceProvider"]?.ToString();
        Resource = logsTableRow["Resource"]?.ToString();
        OperationName = logsTableRow["OperationName"]?.ToString();
        CorrelationId = logsTableRow["CorrelationId"]?.ToString();
        CallerIpAddress = logsTableRow["CallerIPAddress"]?.ToString();
        ClientInfo = logsTableRow["clientInfo_s"]?.ToString();
        Type = logsTableRow["Type"]?.ToString();
        TenantId = logsTableRow["TenantId"]?.ToString();
        SourceSystem = logsTableRow["SourceSystem"]?.ToString();
        TimeGenerated = logsTableRow["TimeGenerated"]?.ToString();
    }
}
