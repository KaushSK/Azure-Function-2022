﻿namespace SoftDeleteDetection.Models;

public static class Settings
{
    public const string LogWorkspaceId = "LogWorkspaceId";
    public const string TenantId = "TenantId";
    public const string ClientId = "ClientId";
    public const string ClientSecret = "ClientSecret";
    
    public const string ReportReceipents = "ReportReceipents";
    public const string SenderEmail = "SenderEmail";
    public const string SenderName = "SenderName";
    public const string SmtpServer = "SmtpServer";
    public const string SmtpPort = "SmtpPort";
    public const string EnableSsl = "EnableSsl";
    public const string SmtpUsername = "SmtpUsername";
    public const string SmtpPassword = "SmtpPassword";
    public const string EmailSubject = "EmailSubject";
}
