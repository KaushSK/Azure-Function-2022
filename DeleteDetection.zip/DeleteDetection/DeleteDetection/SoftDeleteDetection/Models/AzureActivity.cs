﻿using Azure.Monitor.Query.Models;

namespace SoftDeleteDetection.Models;

public record AzureActivity
{
    public string TenantId { get; set; }
    public string SourceSystem { get; set; }
    public string CallerIpAddress { get; set; }
    public string CategoryValue { get; set; }
    public string CorrelationId { get; set; }
    public string Level { get; set; }
    public string OperationNameValue { get; set; }
    public string Properties { get; set; }
    public string Caller { get; set; }
    public string ResourceGroup { get; set; }
    public string TimeGenerated { get; set; }
    public string SubscriptionId { get; set; }
    public string Type { get; set; }
    public string ResourceId { get; set; }

    public AzureActivity(LogsTableRow logsTableRow)
	{
        CallerIpAddress = logsTableRow["CallerIpAddress"]?.ToString();
        CategoryValue = logsTableRow["CategoryValue"]?.ToString();
        CorrelationId = logsTableRow["CorrelationId"]?.ToString();
        Level = logsTableRow["Level"]?.ToString();
        OperationNameValue = logsTableRow["OperationNameValue"]?.ToString();
        Properties = logsTableRow["Properties"]?.ToString();
        Caller = logsTableRow["Caller"]?.ToString();
        SubscriptionId = logsTableRow["SubscriptionId"]?.ToString();
        Type = logsTableRow["Type"]?.ToString();
        ResourceId = logsTableRow["_ResourceId"]?.ToString();
        ResourceGroup = logsTableRow["ResourceGroup"]?.ToString();
        TenantId = logsTableRow["TenantId"]?.ToString();
        SourceSystem = logsTableRow["SourceSystem"]?.ToString();
        TimeGenerated = logsTableRow["TimeGenerated"]?.ToString();
    }
}
