using Azure;
using Azure.Identity;
using Azure.Monitor.Query;
using Azure.Monitor.Query.Models;
using MailKit.Net.Smtp;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using MimeKit;
using SoftDeleteDetection.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftDeleteDetection;

public class NotifyOnSoftDeletedResourcesFunctions
{
    [FunctionName("ScanAndNotify")]
    public static async Task ScanAndNotify([TimerTrigger("0 0 9 * * MON")] TimerInfo myTimer, ILogger log)
    {
        log.LogInformation("ScanAndNotify function executed at: {timestamp}", DateTime.Now);

        var client = GetClient();
        string workspaceId = Environment.GetEnvironmentVariable(Settings.LogWorkspaceId);

        var activities = await GetActivitiesAsync(client, workspaceId);
        log.LogInformation("Received {amount} activities", activities.Count);

        var diagnostics = await GetDiagnosticsAsync(client, workspaceId);
        log.LogInformation("Received {amount} diagnostics", diagnostics.Count);

        if (!activities.Any() && !diagnostics.Any())
        {
            log.LogInformation("Nothing found.");
            return;
        }

        log.LogInformation("Preparing email...");
        var htmlBody = BuildHtmlFromLists(activities, diagnostics);
        var message = GetMessage(htmlBody);
        SendEmail(message);
        log.LogInformation("email sent.");
    }

    #region query data
    private static LogsQueryClient GetClient()
    {
        var creds = new ClientSecretCredential(
            tenantId: Environment.GetEnvironmentVariable(Settings.TenantId),
            clientId: Environment.GetEnvironmentVariable(Settings.ClientId),
            clientSecret: Environment.GetEnvironmentVariable(Settings.ClientSecret)
            );

        return new LogsQueryClient(creds);
    }

    private static async Task<List<AzureActivity>> GetActivitiesAsync(LogsQueryClient client, string workspaceId)
    {
        List<AzureActivity> result = new();

        Response<LogsQueryResult> response = await client.QueryWorkspaceAsync(
            workspaceId,
            "let starttime = 14d; " +
            "AzureActivity " +
            "| where TimeGenerated between (startofday(ago(starttime))..now()) " +
            "| where OperationNameValue endswith \"delete\" ",
            new QueryTimeRange(TimeSpan.FromDays(1)));

        LogsTable table = response.Value.Table;

        foreach (var row in table.Rows)
        {
            result.Add(new AzureActivity(row));
        }

        return result;
    }

    private static async Task<List<AzureDiagnostics>> GetDiagnosticsAsync(LogsQueryClient client, string workspaceId)
    {
        List<AzureDiagnostics> result = new();

        Response<LogsQueryResult> response = await client.QueryWorkspaceAsync(
            workspaceId,
            "let starttime = 14d; " +
            "AzureDiagnostics " +
            "| where TimeGenerated between (startofday(ago(starttime))..now()) " +
            "| where OperationName endswith \"delete\" ",
            new QueryTimeRange(TimeSpan.FromDays(1)));

        LogsTable table = response.Value.Table;

        foreach (var row in table.Rows)
        {
            result.Add(new AzureDiagnostics(row));
        }

        return result;
    }
    #endregion

    #region send mail
    private static string BuildHtmlFromLists(List<AzureActivity> activities, List<AzureDiagnostics> diagnostics)
    {
        StringBuilder sb = new();

        sb.Append("<h1><b>Deletion detection found something</b></h1><br/>");

        #region activities
        if (activities.Any())
        {
            sb.Append("<h2>Found deletion activities!</h2><br/>");
            sb.Append("<table cellpadding=\"0\" cellspacing=\"0\" width=\"640\" border=\"1\"><tr>" +
                "<th>Time Generated</th>" +
                "<th>Tenant</th>" +
                "<th>Source System</th>" +
                "<th>Caller IP Address</th>" +
                "<th>Category</th>" +
                "<th>Correlation Id</th>" +
                "<th>Level</th>" +
                "<th>Operation Name</th>" +
                "<th>Caller</th>" +
                "<th>Resource Group</th>" +
                "<th>Subscription Id</th>" +
                "<th>Type</th>" +
                "<th>Resource ID</th>" +
                "</tr>");

            foreach (var item in activities)
            {
                sb.Append("<tr>" +
                    $"<td>{item.TimeGenerated}</td>" +
                    $"<td>{item.TenantId}</td>" +
                    $"<td>{item.SourceSystem}</td>" +
                    $"<td>{item.CallerIpAddress}</td>" +
                    $"<td>{item.CategoryValue}</td>" +
                    $"<td>{item.CorrelationId}</td>" +
                    $"<td>{item.Level}</td>" +
                    $"<td>{item.OperationNameValue}</td>" +
                    $"<td>{item.Caller}</td>" +
                    $"<td>{item.ResourceGroup}</td>" +
                    $"<td>{item.SubscriptionId}</td>" +
                    $"<td>{item.Type}</td>" +
                    $"<td>{item.ResourceId}</td>" +
                    "</tr>");
            }

            sb.Append("</table>");
        }
        #endregion

        #region diagnostics
        if (diagnostics.Any())
        {
            sb.Append("<h2>Found deletion diagnostics!</h2><br/>");
            sb.Append("<table cellpadding=\"0\" cellspacing=\"0\" width=\"640\" border=\"1\"><tr>" +
                "<th>Time Generated</th>" +
                "<th>Tenant</th>" +
                "<th>Source System</th>" +
                "<th>Caller IP Address</th>" +
                "<th>Category</th>" +
                "<th>Correlation Id</th>" +
                "<th>Resource Provider</th>" +
                "<th>Resource</th>" +
                "<th>Operation Name</th>" +
                "<th>Client Info</th>" +
                "<th>Resource Group</th>" +
                "<th>Subscription Id</th>" +
                "<th>Type</th>" +
                "<th>Resource ID</th>" +
                "</tr>");

            foreach (var item in diagnostics)
            {
                sb.Append("<tr>" +
                    $"<td>{item.TimeGenerated}</td>" +
                    $"<td>{item.TenantId}</td>" +
                    $"<td>{item.SourceSystem}</td>" +
                    $"<td>{item.CallerIpAddress}</td>" +
                    $"<td>{item.Category}</td>" +
                    $"<td>{item.CorrelationId}</td>" +
                    $"<td>{item.ResourceProvider}</td>" +
                    $"<td>{item.Resource}</td>" +
                    $"<td>{item.OperationName}</td>" +
                    $"<td>{item.ClientInfo}</td>" +
                    $"<td>{item.ResourceGroup}</td>" +
                    $"<td>{item.SubscriptionId}</td>" +
                    $"<td>{item.Type}</td>" +
                    $"<td>{item.ResourceId}</td>" +
                    "</tr>");
            }

            sb.Append("</table>");
        }
        #endregion

        return sb.ToString();
    }

    private static MimeMessage GetMessage(string htmlBody)
    {
        MimeMessage result = new();

        // from
        string senderEmail = Environment.GetEnvironmentVariable(Settings.SenderEmail);
        string senderName = Environment.GetEnvironmentVariable(Settings.SenderName);
        result.From.Add(new MailboxAddress(senderName, senderEmail));

        // to
        string receipents = Environment.GetEnvironmentVariable(Settings.ReportReceipents);
        foreach (var receipent in receipents.Split(";", StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            result.To.Add(new MailboxAddress(receipent, receipent));
        }

        // subject
        result.Subject = Environment.GetEnvironmentVariable(Settings.EmailSubject);

        // body
        var bodyBuilder = new BodyBuilder
        {
            HtmlBody = htmlBody,
        };
        result.Body = bodyBuilder.ToMessageBody();

        return result;
    }

    private static void SendEmail(MimeMessage message)
    {
        SmtpClient client = new();

        string server = Environment.GetEnvironmentVariable(Settings.SmtpServer);
        int port = int.Parse(Environment.GetEnvironmentVariable(Settings.SmtpPort));
        bool enableSsl = bool.Parse(Environment.GetEnvironmentVariable(Settings.EnableSsl));
        client.Connect(server, port, enableSsl);

        string username = Environment.GetEnvironmentVariable(Settings.SmtpUsername);
        string password = Environment.GetEnvironmentVariable(Settings.SmtpPassword);
        client.Authenticate(username, password);

        client.Send(message);
        client.Disconnect(true);
    }
    #endregion
}
